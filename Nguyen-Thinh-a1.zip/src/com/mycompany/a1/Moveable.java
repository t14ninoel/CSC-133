//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

public class Moveable extends GameObject {
	
	private int heading = 0; //heading attribute
	private int speed = 0; //speed attribute 

    public Moveable (int size, double x, double y) {
    	super (size, x, y);
    }
    
    public void move() {
    	double tempX = (getX()+(Math.cos(Math.toRadians(90-heading)))*speed);
    	double tempY = (getY()+(Math.sin(Math.toRadians(90-heading)))*speed);
    	
    	// set object inside the screen resolution
    	if (tempX <= 1024 && tempY <= 786 && tempX >= 0 && tempY >= 0) {
    		setX(tempX);
    		setY(tempY);
    	}
    	
    	else {
    		
    		heading -= 45;
    		move();
    	}
    }
    
    public void setSpeed(int speed) {
    	this.speed = speed;
    	}
    
    public int getSpeed() {
    	return speed;
    }
    
    public int getHeading() {
    	return heading;
    }
    
    public void setHeading(int heading) {
    	this.heading=(this.heading+heading);
    }
    
    public String toString() {
    	String parentDesc = super.toString();
    	String myDesc = " heading=" +heading+" speed=" + speed;
    	return parentDesc + myDesc;
    }
}
