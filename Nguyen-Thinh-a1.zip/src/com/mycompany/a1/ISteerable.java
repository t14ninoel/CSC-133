//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

public interface ISteerable {
           // allows objects to change their heading
	
	void changeHeading (char s); 
}
