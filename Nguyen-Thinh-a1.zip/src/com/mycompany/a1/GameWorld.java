//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

import java.util.ArrayList;
import java.util.Random;

import com.codename1.charts.util.ColorUtil;

public class GameWorld {
	//create the initial game objects/setup 
	private int counter = 0;
	private Ant ant;
	private ArrayList<GameObject> gameObjectList = new ArrayList<GameObject>();
	private int flagSize = 10;
	private int antSize = 30;
	private Random rand = new Random();
	private boolean isExit = false;
	
	//quit game options
	public void exit() {
		if (isExit)
			System.exit(0);
	}
	public void quitGame() {
		System.out.println("Do you want to exit? Press y or n!");
		isExit=true;
	}
	public void dontQuit() {
		isExit=false;
		System.out.println("Enter a command");
	}
	
	
	public void init()
    {
    	//reset gameObjectList before the play
		gameObjectList.clear();
		
		//create objects
		gameObjectList.add(new Flags(flagSize, 1, 200, 300)); //flag 1
		gameObjectList.add(new Flags(flagSize, 2, 100, 200)); //flag 2
		gameObjectList.add(new Flags(flagSize, 3, 400, 500)); //flag 3
		gameObjectList.add(new Flags(flagSize, 4, 600, 900)); //flag 4
		
		gameObjectList.add(new FoodStations(randObjSize(), randX(), randY())); //food1
		gameObjectList.add(new FoodStations(randObjSize(), randX(), randY())); //food2
		
		//create Ant player
		gameObjectList.add(ant = new Ant(antSize, 0, 300, 300)); //ant
		
		//create Spider object
		gameObjectList.add(new Spider(randObjSize(), randX(), randY())); //spider 1
		gameObjectList.add(new Spider(randObjSize(), randX(), randY())); //spider 2
    }
	
	//display game
	public void display() {
		System.out.println("Number of lives remaining: " + ant.getLives()
		+       ", Current time: "+counter+", Last Flag Reached: "+ant.getLastFlag()+", Health Lvel: "
		+ant.getFoodLevel()+", Health: "+ant.getHealthLevel());
	}
	
	//display game map
	public void map() {
		for (GameObject temp: gameObjectList) {
			System.out.println(temp);
		}
	}
	
	private void lifeReset() {
		ant.resetAnt();
	}
	
	// tick command
	public void tick() {
		if(ant.getHealthLevel()!=100 && ant.getFoodLevel() !=0 && ant.getLives()!=0){
			ant.setHeading(ant.getHeading());
			ant.setFoodLevel(300);
			counterTime();
		
		
		for(GameObject temp: gameObjectList) {
			if(temp instanceof Moveable) {
				if(temp instanceof Spider) {
					((Moveable) temp).setHeading(((Moveable) temp).getHeading());
					((Moveable) temp).move();
				}
				
				else
					((Moveable) temp).move();
			}
		}
	}
		else {
			if (ant.getLives()!= 0) {
				lifeReset();
			}
			else
			{
				System.out.println("Game over, you failed!");
			}
		}
		
	}
	
	//Create randInts
	private int randX() {
		return rand.nextInt(1024);
	}
	
	private int randY() {
		return rand.nextInt(768);
	}
	
	private int randObjSize() {
		return 30+rand.nextInt(50);
	}
	
	public void antCollision(char with) {
		ant.collision(with);
	}
	
	public void flagCollision (int flagNumber) {
		ant.FlagCollision(flagNumber);
	}
	
	public void setAntSpeed(int x) {
		ant.setSpeed(ant.getSpeed()+x);
	}
	
	public void changeHeading (char change) {
		ant.changeHeading(change);
	}
	
	public void foodStationCollision() {
		for(GameObject temp: gameObjectList) {
			if (temp instanceof FoodStations) {
				if(((FoodStations) temp).getCapacity()!=0) {
					ant.setFoodLevel(((FoodStations) temp).getCapacity());
					((FoodStations)temp).setCapacity();
					temp.setColor(ColorUtil.rgb(0, 255, 0));
				}
			}
		}
		gameObjectList.add(new FoodStations(randObjSize(), randX(), randY()));
	}
	
	public void counterTime() {
		counter += 1;
	}
	
	
}

