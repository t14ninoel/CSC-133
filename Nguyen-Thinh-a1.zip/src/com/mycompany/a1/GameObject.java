//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

import com.codename1.charts.util.ColorUtil;

public class GameObject {
	private int myColor; //color attribute
	private double x = 0; //location attribute
	private double y = 0; //location attribute
	private int mySize; //size attribute
	
	public GameObject(int size, double x, double y) {
		this.mySize = size;
		this.x = x;
		this.y = y;     
	}

	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setX(double x) {
		this.x = x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public void setColor(int color) {
		myColor = color;
	}
	
	public int getColor() {
		return myColor;
	}
	
	public void setSize(int size) {
		mySize = size;
	}
	
	public int getSize() {
		return mySize;
	}
	
	public String toString() {
		
		String myDesc = "  location=" + Math.round(x*10.0)/10.0 + "," + Math.round(y*10.0)/10.0 +
				" color=[" + ColorUtil.red(myColor)+ "," +ColorUtil.green(myColor) + "," +ColorUtil.blue(myColor) + "]" 
				+ " size=" + mySize;
		return myDesc;
	}
}
