//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

import java.util.Random;
import com.codename1.charts.util.ColorUtil;

public class Spider extends Moveable {
	
	private Random rand  = new Random();
	
	public Spider (int size, double x, double y) {
		super (size, x, y);
		super.setColor(ColorUtil.rgb(87, 26, 255)); //set spider color
		setSpeed(randSpeed());
		setHeading(randHeading());
	}
	
	

	public String toString() {
		String parentDesc = super.toString();
		return "Spider:" + parentDesc;
	}
	
	@Override
	public void setColor (int color) 
	{
		//empty since spider are not allowed to change color once they are created
	}
	
	
	@Override
	public void setHeading(int heading) {
		super.setHeading(randValue());
	}
	
	private int randValue() {//degrees to heading 
		return((-5) + rand.nextInt(10));
	}
	
	private int randHeading() {// set heading of spider random from 0 to 359
		return rand.nextInt(359);
	}
	
	private int randSpeed() {// speed of spider from 5 to 10
		return 5 + rand.nextInt(10);
	}

}
