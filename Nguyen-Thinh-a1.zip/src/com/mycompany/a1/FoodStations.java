//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

import com.codename1.charts.util.ColorUtil;

public class FoodStations extends Fixed {
	
	private int capacity; // attribute capacity (amount of food a food station contains
	
	public FoodStations(int size, double x, double y) {
		super(size, x, y);
		super.setColor(ColorUtil.rgb (0, 222, 255)); // set color to blue 
		capacity = size;
	}
	
	public int getCapacity()
	{
		return capacity;
	}
	
	public void setCapacity()
	{//set initial capacity 
		capacity = 0;
	}

	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " capacity="+capacity;
		return "FoodStation:" + parentDesc + myDesc;
	}
}
