//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

public class Fixed extends GameObject{
	
	public Fixed(int size, double x, double y) {
		super(size, x, y);
	}
	
	@Override
	public void setX(double x) {
		// not change once created
	}
    
	@Override
	public void setY(double y) {
		// not change once created
	}
}
