//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

import com.codename1.charts.util.ColorUtil;


public class Flags extends Fixed{
	
	private int sequenceNumber;
	
	// set the color
	public Flags(int size, int sequenceNumber, double x, double y)
	{
		super(size, x, y);
		super.setColor(ColorUtil.rgb(255, 0, 0)); // set color to red
		this.sequenceNumber = sequenceNumber;
	}
	
	//get number of flags
	public int getSequenceNumber(){
		return sequenceNumber;
	}
	
	@Override
	public void setColor(int color) {
		//empty since flags are not allowed to change color once they are created
	}
	
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " sequenceNumber="+sequenceNumber;
		return "Flag:" + parentDesc + myDesc;
	}

}
