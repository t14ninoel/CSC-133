//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a1;

import com.codename1.ui.*;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import java.lang.String;

public class Game extends Form {
	
	private GameWorld gw;
	
	public Game()
	{
		gw = new GameWorld();
		gw.init();
		play();
	}
	
	@SuppressWarnings("rawtypes")
	private void play() {
		//accept and execute user commands that operate on the game world
		Label myLabel=new Label("Enter a Command:");
		this.addComponent(myLabel);
		final TextField myTextField=new TextField();
		this.addComponent(myTextField);
		this.show();
		
		myTextField.addActionListener(new ActionListener(){
		
			public void actionPerformed(ActionEvent evt) {
		
				String sCommand=myTextField.getText().toString();
				myTextField.clear();
		        switch (sCommand.charAt(0)) {
		        	
		        case 'a':
		        	// accelerate
		        	gw.setAntSpeed(5);
		        	break;
		        	
		        case 'b':
		            //brake
		        	System.out.println("Break is applied");
		        	gw.setAntSpeed(-5);
		        	break;
		        
		        case 'l':
		        	//change heading to left
		        	gw.changeHeading('l');
		        	break;
		        	
		        case 'r':
		        	//change heading to right
		        	gw.changeHeading('r');
		        	break;
		        	
		        case '1':
		        	//flag 1
		        	gw.flagCollision(1);
		        	break;
		        
		        case '2':
		        	//flag 2
		        	gw.flagCollision(2);
		        	break;
		        	
		        case '3':
		        	//flag 3
		        	gw.flagCollision(3);
		        	break;
		        	
		        case '4':
		        	//flag 4
		        	gw.flagCollision(4);
		        	break;
		        	
		        case '5':
		        	//flag 5
		        	gw.flagCollision(5);
		        	break;
		        	
		        case '6':
		        	//flag 6
		        	gw.flagCollision(6);
		        	break;
		        	
		        case '7':
		        	//flag 7
		        	gw.flagCollision(7);
		        	break;
		        	
		        case '8':
		        	//flag 8
		        	gw.flagCollision(8);
		        	break;
		        	
		        case '9':
		        	//flag 9
		        	gw.flagCollision(9);
		        	break;
		        	
		        case 'f':
		        	//food station collision
		        	gw.foodStationCollision();
		        	break;
		        	
		        case 'g':
		        	//spider collision
		        	gw.antCollision('d');
		        	break;
		        	
		        case 't':
		        	gw.tick();
		        	break;
		        	
		        case 'd':
		        	gw.display();
		        	break;
		        	
		        case 'm':
		        	gw.map();
		        	break;
		        	
		        case 'x':
			        	// Exit game
		        	    myLabel.setText("Do you want to exit? Press y or n!");
			        	gw.quitGame();
			        	break;	
			        	
		        case 'y':
		        	gw.exit();
		        	break;
		        	
		        case 'n':
		        	myLabel.setText("Enter a command!");
		        	gw.dontQuit();
		        	break;
		        	
		        	
		        	
		//add code to handle rest of the commands
		} //switch
		} //actionPerformed
		}); //new ActionListener()
		 //addActionListener
		} //play
}	
	

				



