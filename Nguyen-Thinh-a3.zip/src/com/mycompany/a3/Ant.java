//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;

public abstract class Ant extends Moveable implements ISteerable {
	
	private int maximumSpeed = 30; // set ant speed
	private int foodLevel = 100; // set food level
	double nonDisplayfood = 100.00; // set nondisplayfood
	private double foodConsumptionRate = 1.00; // set food consumption rate
	private int healthLevel = 0; // set health
	private int lastFlagReached = 1; 
	private int lives = 3; // set lives
	private GameWorld gw;
	private int red = 255; // set ant color circle to red
	private int direction; // set direction
	
	/**
	 * Constructor for Ant
	 * @param x
	 * @param y
	 */
	public Ant(GameWorld gw,int size, int heading,double x, double y) {//
		super(gw,size, x, y);
		super.setSpeed(10);
		super.setColor(ColorUtil.rgb(red, 0, 0));
		this.gw = gw;
	}
	
	
	public int getRed(){
		return red;
	}
	public void setRed(int addIt) {
		red -= addIt;
	}
	public int getLives() {
		return lives;
	}
	
	public int getHealthLevel() {
		return healthLevel;
	}
	
	public int getFoodLevel() {
		return foodLevel;
	}
	
	public int getDirection() {
		return direction;
	}
	
	public int getLastFlag() {
		return lastFlagReached;
	}
	
	@Override
	public void changeDirection(char s) {
		if(s=='l')
			if(direction >= (-35))
				direction-=5;
		if(s=='r')
			if(direction <= 35)
				direction+=5;
		}
	@Override
	public void setSpeed(int speed) {//set ant speed
		if(speed <= (maximumSpeed) && speed >=0 )
			super.setSpeed(speed);
	}
	public void checkSpeed() {//checks the speed when ant takes damage
		
		maximumSpeed=(int) (30-(30*(healthLevel/100.00)));
		if (getSpeed()>maximumSpeed)
			setSpeed(maximumSpeed);
	}
	public void setHealth(int health) {
		healthLevel += health;
	}
	public void collision(char with) {//Called when a collision with spider
		if(healthLevel!=100) {
		if(with=='r') {
			healthLevel += 10;
			setColor(ColorUtil.rgb((red-=10), 0, 0));
			checkSpeed();
			gw.setCrashCol(true);
			
		}
		if(with=='s') {//spider collision
			healthLevel += 5;
			setColor(ColorUtil.rgb((red-=5), 0, 0));
			checkSpeed();
			
		}
		}
	}
	public void flagCollision(int flagNumber) {// called when collision with flags
		if(flagNumber==(lastFlagReached+1))
			lastFlagReached=flagNumber;
	}
	
	public void setFoodLevel(int food) {
		if (food == 300) {
			nonDisplayfood-=(foodConsumptionRate/(1000.00/20.00));
			
				foodLevel=(int) nonDisplayfood;
		}
		else {
			nonDisplayfood=foodLevel+=food;
			if(foodLevel>100)
			nonDisplayfood=foodLevel=100;
		}
	}
	
	
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " maxSpeed=" + maximumSpeed + " heading="+direction+ " foodLevel="+ foodLevel+ " healthLevel=" + healthLevel + "lives:  "+lives;
		return parentDesc + myDesc;
		
	}
	
	public void resetAnt() {
		setX(500);
		setY(500);
			healthLevel=0;
			foodLevel=100;
			lives-=1;
		
	}
	
	
}