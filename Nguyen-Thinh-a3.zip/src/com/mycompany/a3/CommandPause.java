//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.ui.*;
import com.codename1.ui.events.ActionEvent;


public class CommandPause extends Command {

	private GameWorld gw;

	
	public CommandPause(GameWorld gw) {
		super("Pause");
		this.gw = gw;
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		if(gw.isIspause()) {
			System.out.println("Continue the Game");
			gw.setIspause(false);
		}
			
		else {
		System.out.println("Pause the Game");
		gw.setIspause(true);
		}
	}
	
}