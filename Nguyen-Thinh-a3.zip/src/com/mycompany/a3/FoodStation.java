//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class FoodStation extends Fixed {
	
	private int capacity, size;

	
	public FoodStation(GameWorld gw,int size, double x, double y) {
		super(gw,size, x, y);
		super.setColor(ColorUtil.rgb(0,255, 0));
		capacity = size;
		this.size=size;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void setCapacity() {
		capacity=0;
	}
	
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " capacity="+capacity;
		return "Food Station:" + parentDesc + myDesc;
	
	}
	
	// draw food station as square
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int locX = (int)getX() + (int)pCmpRelPrnt.getX();
        int locY = (int)getY() + (int)pCmpRelPrnt.getY();
        g.setColor(getColor());
        g.fillRect(locX, locY, size, size);
	}
	
	

}