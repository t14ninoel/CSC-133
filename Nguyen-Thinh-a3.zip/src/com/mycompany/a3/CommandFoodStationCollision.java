//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CommandFoodStationCollision extends Command {


	@SuppressWarnings("unused")
	private GameWorld gw;

	
	public CommandFoodStationCollision(GameWorld gw) {
		super("Collided with Food Station");
		this.gw = gw;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		
	}
	
}