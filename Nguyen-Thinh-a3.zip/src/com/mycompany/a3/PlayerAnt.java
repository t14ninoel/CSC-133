//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class PlayerAnt extends Ant {
	private int size;
	@SuppressWarnings("unused")
	private double x, y;

	public PlayerAnt(GameWorld gw,int size, int direction, double x, double y) {
		super(gw,size, direction, x, y);
		this.x =x;
		this.y=y;
		this.size=size;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		String parentDesc = super.toString();
		return "Ant:" + parentDesc;
	}
	
	//draw Ant as circle
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
        g.setColor(getColor());
        if(!isSelected()) {
        g.fillArc((int)(pCmpRelPrnt.getX()+this.getX())
        		, (int)(pCmpRelPrnt.getY()+this.getY())
        		, this.size, size, 0, 360);
        }else {
        	g.drawArc((int)(pCmpRelPrnt.getX()+this.getX())
            		, (int)(pCmpRelPrnt.getY()+this.getY())
            		, this.size, size, 0, 360);
        }
        
        
        int locX = (int)getX() + (int)pCmpRelPrnt.getX();
        int locY = (int)getY() + (int)pCmpRelPrnt.getY();
        g.setColor(0x000000);
        String copacityNum = Integer.toString(size);
        g.drawString(copacityNum, locX, locY);
	}
	private boolean isSelected() {
		// TODO Auto-generated method stub
		return false;
	}
}