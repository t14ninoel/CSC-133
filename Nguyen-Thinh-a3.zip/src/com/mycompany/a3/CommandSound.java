//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a3.GameWorld;

public class CommandSound extends Command {
	private GameWorld gw;
	
	public CommandSound(GameWorld gw) {
		super("Sound");
		this.gw = gw;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.toggleSound();
		
	}

}
