//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;


import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Toolbar;
import com.codename1.ui.util.UITimer;


public class Game extends Form implements Runnable{
	private GameWorld gw;
	private ScoreView scoreView;
	private MapView mapView;
	private Command pauseCommand;
	private Button pauseButton;
	@SuppressWarnings("unused")
	private boolean isSelected = true;
	@SuppressWarnings("unused")
	private static int mapX, mapY;
	private BGSound bgSound = new BGSound("BackGroundMusic.wav");
	public Game() {
		gw = new GameWorld();
		scoreView = new ScoreView(gw);
		mapView = new MapView(gw);
		
		//gw.init();
		//play();
		this.setLayout(new BorderLayout());
		Command exitCommand = new CommandExit(gw);
		Command accelerateCommand = new CommandAccelerate(gw);
		Command leftCommand = new CommandLeftHeading(gw);
		Command brakeCommand = new CommandBrake(gw);
		Command rightCommand = new CommandRightHeading(gw);
		Command foodCommand = new CommandFoodStationCollision(gw);
		Command positionCommand;
		positionCommand = new CommandPosition(gw);
		pauseCommand = new CommandPause(gw);
		
		
		addKeyListener('x', exitCommand);
		addKeyListener('a', accelerateCommand);
		addKeyListener('b', brakeCommand);
		addKeyListener('l', leftCommand);
		addKeyListener('r', rightCommand);
		addKeyListener('f', foodCommand);
		
		//West Container
		Container westContainer = new Container();
		westContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.GRAY));
		westContainer.setLayout(new BoxLayout(2));
		
		//Accelerate
		Button accelerateButton = new Button("Accelerate");
		accelerateButton.setCommand(accelerateCommand);
		westContainer.addComponent(accelerateButton);
		accelerateButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		accelerateButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		accelerateButton.getAllStyles().setBgTransparency(255);
		accelerateButton.getAllStyles().setMarginBottom(10); 
		
		
		
		//Left
		Button leftButton = new Button("Left");
		leftButton.setCommand(leftCommand);
		westContainer.addComponent(leftButton);	
		leftButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		leftButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		leftButton.getAllStyles().setBgTransparency(255);	
		leftButton.getAllStyles().setMarginBottom(10);
		
		
		//East Container 
		Container eastContainer = new Container();
		eastContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.GRAY));
		eastContainer.setLayout(new BoxLayout(2));
		
		//Brake
		Button brakeButton = new Button("Break");
		brakeButton.setCommand(brakeCommand);
		eastContainer.addComponent(brakeButton);
		brakeButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		brakeButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		brakeButton.getAllStyles().setBgTransparency(255);	
		brakeButton.getAllStyles().setMarginBottom(10);
		
		//Right
		Button rightButton = new Button("Right");
		rightButton.setCommand(rightCommand);
		eastContainer.addComponent(rightButton);
		rightButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		rightButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		rightButton.getAllStyles().setBgTransparency(255);	
		rightButton.getAllStyles().setMarginBottom(10);
		
		Container centerContainer = new Container();
		centerContainer.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.MAGENTA));
		
		//South Container
		Container southContainer = new Container();
		southContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.GRAY));
		southContainer.setLayout(new FlowLayout(Component.CENTER));
		
		
		Button positionButton = new Button("Position");
		southContainer.addComponent(positionButton);
		positionButton.setCommand(positionCommand);
		positionButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		positionButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		positionButton.getAllStyles().setBgTransparency(255);	
		positionButton.getAllStyles().setMarginRight(5);
		positionButton.getDisabledStyle().setFgColor(ColorUtil.BLUE);
		positionButton.getDisabledStyle().setBgColor(ColorUtil.WHITE);
		
		pauseButton = new Button("Pause");
		southContainer.addComponent(pauseButton);
		pauseButton.setCommand(pauseCommand);
		pauseButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		pauseButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		pauseButton.getAllStyles().setBgTransparency(255);	
		pauseButton.getAllStyles().setMarginRight(5);
		
		//setup the toolbar for the gui
		Toolbar toolbar = new Toolbar();
		this.setToolbar(toolbar);
		toolbar.setTitle("BugZ Game ");
		
		//Acc,left and change 
		toolbar.addCommandToSideMenu(accelerateCommand);
		Command soundCommand = new CommandSound(gw);
		CheckBox soundCheck = new CheckBox("Sound");
		soundCheck.setCommand(soundCommand);
		toolbar.addComponentToSideMenu(soundCheck );
		Command aboutInfoCommand = new CommandAbout(gw);
		toolbar.addCommandToSideMenu(aboutInfoCommand);

		toolbar.addCommandToSideMenu(exitCommand);	
		
		Command helpButton = new CommandHelp(gw);
		toolbar.addCommandToRightBar(helpButton);
		
		this.add(BorderLayout.WEST, westContainer);
		this.add(BorderLayout.EAST, eastContainer);
		this.add(BorderLayout.SOUTH, southContainer);
		this.add(BorderLayout.NORTH, scoreView);
		this.add(BorderLayout.CENTER, mapView);
		gw.setMapHeight(mapView.getComponentForm().getHeight());
		gw.setMapWidth(mapView.getComponentForm().getWidth());
		
		this.show();
		gw.setWidthHeight(mapView.getComponentForm().getX(), mapView.getComponentForm().getY());
		gw.setMapHeight(mapView.getComponentForm().getHeight());
		gw.setMapWidth(mapView.getComponentForm().getWidth());
		gw.init();
		UITimer timer = new UITimer(this);
		timer.schedule(20, true, this);



		play();
	}
	private void play() {
		
	}
	public void playSounds() {
		if(gw.isSound()) {
		if(gw.isFoodCol()) {
			gw.setFoodCol(false);
			Sound foodSound = new Sound("AntCollidesFoodStation.wav", "audio/wav");
			if(!gw.isIspause())
				foodSound.play();
			
		}
		if(gw.isCrashCol()) {
			gw.setCrashCol(false);
			Sound crashSound = new Sound("AntCollidesFlag.wav", "audio/wav");
			if(!gw.isIspause())
				crashSound.play();
		}
		
		if(gw.isDeathCol()) {
			gw.setCrashCol(false);
			Sound deathSound = new Sound("AntCollidesSpider.wav", "audio/wav");
			if(!gw.isIspause())
				deathSound.play();
		}
		if(gw.isIspause()) {
			bgSound.pause();
		}else {
			
		bgSound.play(gw.isIspause());
		}
		
		}
		else {
			bgSound.pause();
		}
		
	}
	@Override
	public void run() {
		
		if(gw.isIspause()) {
			pauseButton.setText("Play");
			bgSound.pause();
		}
		else {
			pauseButton.setText("Pause");
			playSounds();
			gw.tick(20);
		}
	}
	
	
}
		
		

		
	
	


	
	

					
				
				
			
		



	