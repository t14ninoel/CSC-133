package com.mycompany.a3;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;

public class CommandExit extends Command {


	private GameWorld gw;


	public CommandExit(GameWorld gw) {
		super("Exit");
		this.gw = gw;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.quitGame();
		Command yes = new Command("Yes");
		Command  no  = new Command("No");
		
		Label label1 = new Label("");
		
		Command c = Dialog.show("Do you want to exit the game?", label1, yes, no);
		
		if(c == yes) {
			gw.exit();
		}
		else if (c == no) {
			gw.dontQuit();
		}
	}
}