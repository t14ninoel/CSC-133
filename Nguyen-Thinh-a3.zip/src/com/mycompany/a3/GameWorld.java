//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;


import java.util.ArrayList;

import java.util.Observable;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
	
	public class GameWorld  extends Observable{
		private int mapHeight;
		private boolean positionable, foodCol= false, crashCol= false, deathCol=false;
		private int mapWidth;
		private int contWidth,contHeight;
		private Random rand = new Random();
		private int counter = 0;
		private PlayerAnt ant ;
		private double nonDisplayClock;
		@SuppressWarnings("unused")
		private int lives;
		@SuppressWarnings("unused")
		private GameObject lastCollsion;
		private int flagSize = 50;
		private boolean ispause = false;
		private int antSize = 80;
		private boolean isExit = false;
		private ArrayList<GameObject> colliderList = new ArrayList<GameObject>();
		
		private boolean soundOn = false;
		GameObjectCollection gameObjectList;
		public GameWorld() {
			gameObjectList = new GameObjectCollection();
			 ant= new PlayerAnt(this, antSize, 0, 500, 500);
			 lastCollsion = ant;
		}
		public int getMapWidth() {
			return mapWidth;
		}
		public int getMapHeight() {
			return mapHeight;
		}
		//Exits for the game
		public void exit() {
			if (isExit)
				System.exit(0);
		}
		public void setMapWidth(int width) {
			mapWidth = width;
		
		}
		public void setMapHeight(int height) {
			this.mapHeight = height;
			
		}
		public void quitGame() {
			System.out.println("Do you want to exit the game?");
			isExit=true;
		}
		public void dontQuit() {
			isExit=false;
		}
		public void setWidthHeight(int width, int height) {
			contWidth = width;
			contHeight=height;
		}
		public int getContWidth(){
			return contWidth;
		}
		public int getContheight(){
			return contHeight;
		}
		
		public void init() {
		
			
			
			//Creating Flag and Food Station 
			gameObjectList.add(new Flag(this,flagSize, 1,300, 125));
			gameObjectList.add(new Flag(this,flagSize, 2,200, 500));
			gameObjectList.add(new Flag(this,flagSize, 3,500, 400));
			gameObjectList.add(new Flag(this,flagSize, 4,1000, 125));
			gameObjectList.add(new FoodStation(this, randObjSize(),randX(),randY()));
			gameObjectList.add(new FoodStation(this, randObjSize(),randX(),randY()));
			
			//addsplayer ant
			gameObjectList.add(ant);
		
			
			
			//creates attack spiders
			gameObjectList.add(new Spider(this, randObjSize(), randX(), randY()));
			gameObjectList.add(new Spider(this,randObjSize(), randX(), randY()));
			
			
		}
	
		public void display() {
			System.out.println("Time: "+counter+", Lives left: "+ant.getLives()
			+	", Food Level: "+ant.getFoodLevel()+", Health Level: "+ant.getHealthLevel());
			
		}
		public void map() {
			IIterator elements = gameObjectList.getIterator();
			while (elements.hasNext()) {
				GameObject temp = ((GameObject) elements.getNext());
				System.out.println(temp.toString());
			}
		}
		public void toggleSound() {
			if(!soundOn)
				soundOn=true;
			else
				soundOn=false;
			this.setChanged();
			this.notifyObservers();
		}
		

		public void tick(int elapsedTime) {
			if(ant.getLastFlag() == 4) {
				System.out.print("You are the Winner");
				System.exit(0);
			}
				
			if((ant.getHealthLevel()!=100 && ant.getHealthLevel() <=100) && ant.getFoodLevel() !=0 && ant.getLives()!=0) {
				ant.setHeading(ant.getDirection());
				ant.setFoodLevel(300);
				counterTime();
			
				IIterator elements = gameObjectList.getIterator();
				while ( elements.hasNext()) {
					GameObject temp = ((GameObject) elements.getNext());
					if(temp instanceof Moveable) {
						if(temp instanceof Spider) {
							((Moveable) temp).setHeading(((Moveable) temp).getHeading());
							((Moveable) temp).move(this, elapsedTime);
						}
					else
						((Moveable) temp).move(this, elapsedTime);
					}
				}
				IIterator theColliders = gameObjectList.getIterator();
				
		        while(theColliders.hasNext()){
		            GameObject curObj = (GameObject)theColliders.getNext(); // get a collidable object 
		           
		            if (ant.collidesWith(curObj)) {

		                if (!colliderList.contains((GameObject)curObj)) {
		                    colliderList.add((GameObject) curObj);
		                    ant.handleCollision(curObj);

		                }
		            } else {
		                colliderList.remove((GameObject) curObj);

		            }
		        }

				
		}
			else {
				if(ant.getLives()!=0) {
					deathCol =true;
					ant.setHealth(0);
					lifeReset();
				}
				else {
					System.out.println("Game Over! You Lost");
				}
			}
			notifyobs();
		}
		
		public void antCollision(char with) {
			
			ant.collision(with);
			IIterator iterator = gameObjectList.getIterator();
			while(iterator.hasNext()) {
				GameObject temp = (GameObject) iterator.getNext();
				if(temp instanceof PlayerAnt) {
					((PlayerAnt) temp).collision('r');
					break;
				}
			}
			notifyobs();
		}
		
		public void flagCollision(int flagNumber) {
			ant.flagCollision(flagNumber);
			notifyobs();
			
		}
		public void setAntSpeed(int x) {
			ant.setSpeed(ant.getSpeed()+x);
			notifyobs();
		}
		public void changeDirection(char change) {
			ant.changeDirection(change);
			notifyobs();
		}
		public int getLives() {
			return ant.getLives();
		}
		public int getClock() {
			return counter;
		}
		public int getAntFlagReached() {
			return ant.getLastFlag();
		}
		public int getFoodLevel() {
			return ant.getFoodLevel();
		}
		public int getHealthLevel() {
			return ant.getHealthLevel();
		}
		public boolean isSound() {
			return soundOn;
		}
		public void foodStationCollision(GameObject temp) {
			foodCol = true;

					if(((FoodStation) temp).getCapacity()!=0) {
						ant.setFoodLevel(((FoodStation) temp).getCapacity());
						((FoodStation) temp).setCapacity();
						temp.setColor(ColorUtil.rgb(0, 255, 191));
						
					}
				
			
			gameObjectList.add(new FoodStation(this,randObjSize(), randX(), randY()));
			notifyobs();
		}
		private void notifyobs() {
			this.setChanged();
			this.notifyObservers();
		}
		
		public void counterTime() {
			nonDisplayClock += (1/50.00);
			counter=(int) nonDisplayClock;
		}
		private void lifeReset() {
			ant.resetAnt();
			setDeathCol(true);
		}
		//Creating randInts for the game
		private int randX() {
			return rand.nextInt((mapWidth-contWidth));
		}
		private int randY() {
		
			return rand.nextInt((mapHeight-contHeight));
		}
		private int randObjSize() {
			return 50+rand.nextInt(60);
		}
		public Ant getAnt() {
			// TODO Auto-generated method stub
			return ant;
		}
		public boolean isIspause() {
			return ispause;
		}
		public void setIspause(boolean ispause) {
			this.ispause = ispause;
		}
		public boolean isPositionable() {
			return positionable;
		}
		public void setPositionable(boolean positionable) {
			this.positionable = positionable;
		}
		public boolean isFoodCol() {
			return foodCol;
		}
		public void setFoodCol(boolean energyCol) {
			this.foodCol = energyCol;
		}
		public boolean isCrashCol() {
			return crashCol;
		}
		public void setCrashCol(boolean crashCol) {
			this.crashCol = crashCol;
		}
		public boolean isDeathCol() {
			return deathCol;
		}
		public void setDeathCol(boolean deathCol) {
			this.deathCol = deathCol;

		}
	}
		
		
		
