//Name: Thinh Dac Nguyen
//Student ID: 219903243
//A3Prj
//CSC 133 FALL 2019 

package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.table.TableLayout;

public class CommandAbout extends Command{
	@SuppressWarnings("unused")
	private GameWorld gw;
	
	
	public CommandAbout(GameWorld gw) {
		super("About");
		this.gw = gw;
	}
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		
		Dialog aboutBox = new Dialog("About", new TableLayout(4,1));
		Command okCommand = new Command("ok");
		
		aboutBox.add(new Label ("BugZ Game"));
		aboutBox.add(new Label ("Ver 3.0"));
		aboutBox.add(new Label ("Author: Thinh Nguyen"));
		aboutBox.add(new Label ("CSC 133 A3Prj Fall 2019"));
		
		Command c = Dialog.show("",  aboutBox, okCommand);
		if (c == okCommand) {
			return;
		}
		
	}
	

}
