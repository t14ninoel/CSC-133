//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import java.util.Observer;
import java.util.Observable;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.*;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer {
	
	private GameWorld model;
	public MapView(Observable myModel) {
		model = (GameWorld) myModel;
		myModel.addObserver(this);
		this.getAllStyles().setBorder(Border.createLineBorder(4,
				ColorUtil.MAGENTA));
	}
	
	public MapView () {
		
	}
	
	public void update (Observable o, Object arg) {
		model.map();
	
	}
}
