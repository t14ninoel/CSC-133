//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;

public class Ant extends Moveable implements ISteerable {
	
	private int maximumSpeed = 50; // maximum attribute set to 50
	private int foodLevel = 25; // food level attribute set to 25
	private int foodConsumptionRate = 20; // food consumption attribute set to 20
	private int healthLevel = 10; // health level attribute set to 10
	private int lastFlagReached = 1; // last Flag attribute set to 1
	private int colorAnt = 255;
	private int lives = 3; // player has 3 lives
	private int heading; 
	
	//Constructor for Ant
	public Ant(int size, int heading, double x, double y) {
		super(size, x, y);
		super.setSpeed(5);
		super.setColor(ColorUtil.rgb (colorAnt, 0, 0)); // initial color to red
	}
	
	public int getLives()
	{
		return lives;
	}
	
	public int getLastFlag() {
		return lastFlagReached;
	}
	
	public int getHealthLevel()
	{
		return healthLevel;
	}
	
	public int getFoodLevel() {
		return foodLevel;
	}
	
	public int getHeading() {
		return heading;
	}
	
	@Override
	public void changeHeading(char s) {
		if (s=='l') // 5 degrees to the left
			if(heading >= (-35))
			heading -=5;
		if (s=='r') // 5 degrees to the right
			if(heading <= 35)
			heading +=5;
	}
	
	@Override
	public void setSpeed(int speed) {//set ant speed
		if(speed <= (maximumSpeed) && speed >= 0)
			super.setSpeed(speed);
	}
	
	private void checkSpeed() { //check ant speed
		maximumSpeed = (int) (50-(50*(healthLevel/100.00)));
		if (getSpeed() > maximumSpeed)
			setSpeed(maximumSpeed);
	}
	
	public void collision (char with) {//collision with spider 
		if (healthLevel != 100) {
			if(with == 's') {//spider 
				healthLevel += 5;
				setColor(ColorUtil.rgb(colorAnt-=5, 0, 0));
				checkSpeed();
				} 
		}
	}
	
	public void FlagCollision (int flagNumber) {
		if (flagNumber == (lastFlagReached +1))
			lastFlagReached = flagNumber;
	}
	
	public void setFoodLevel (int food) {
		if (food == 300)
			foodLevel -=foodConsumptionRate;
		else {
			foodLevel+=food;
			if(foodLevel>100)
				foodLevel=100;
		}
	}
	
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " maxSpeed=" + maximumSpeed + " foodConsumptionRate=" + foodConsumptionRate + " heading=" + heading + " foodLevel=" + foodLevel + " healthLevel=" + healthLevel;
		return "Ant:" + parentDesc + myDesc;
		
	}
	
	public void resetAnt() {
		setX(500);
		setY(500);
		healthLevel = 10;
		foodLevel = 100;
		lives -=1;
	}
	

}
