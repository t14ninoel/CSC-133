//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

public interface IIterator {

	public boolean hasNext();
	public Object getNext();
	IIterator getIterator();
	void add(Object object);
	
}
