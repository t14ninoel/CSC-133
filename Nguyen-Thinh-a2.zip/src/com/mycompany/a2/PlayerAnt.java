//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

public class PlayerAnt extends Ant{
	
	public PlayerAnt(int size, int heading, double x, double y) {
		super(size, heading, x, y);
		
	}
	//override of toString
	@Override
	public String toString() {
		String parentDesc = super.toString();
		return "Ant:" + parentDesc;
	}
	public void setLastflagReached(int flagNum) {
		// TODO Auto-generated method stub
		
	}

}
