//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CommandFoodStationCollision extends Command {


	private GameWorld gw;

	//food station
	public CommandFoodStationCollision(GameWorld gw) {
		super("Collided with Food Station");
		this.gw = gw;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.foodStationCollision();
	}
	
}