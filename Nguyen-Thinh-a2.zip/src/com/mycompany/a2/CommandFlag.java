//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CommandFlag extends Command {

	private GameWorld gw;

	
	//flag
	public CommandFlag(GameWorld gw) {
		super("Collide with Flag");
		this.gw = gw;
	}
	
	
	
	public void actionPerformed(ActionEvent ev, int flagNumber) {
		
		gw.flagCollision(flagNumber);
	}
}