//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

public interface ICollection {

    public void add(Object object);
	public IIterator getIterator();
	
}
