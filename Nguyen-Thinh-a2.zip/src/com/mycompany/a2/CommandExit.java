//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;

public class CommandExit extends Command {
	private GameWorld gw;

	//exit
	public CommandExit(GameWorld gw) {
		super("Exit");
		this.gw = gw;
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		//gw.exit();
		Command yes = new Command("yes");
		Command  no  = new Command("no");
		
		Label label1 = new Label("");
		
		Command c = Dialog.show("Do you want to exit?", label1, yes, no);
		
		if(c == yes) {
			gw.exit();
		}
		else if (c == no) {
			return;
		}
	}
}
