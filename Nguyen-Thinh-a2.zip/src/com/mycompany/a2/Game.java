//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.ui.*;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import java.lang.String; 
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border; 

public class Game extends Form {
	
	private GameWorld gw;
	private MapView mv;
	private ScoreView sv;
	
	public Game()
	{
		gw = new GameWorld();
		mv = new MapView(gw);
		sv = new ScoreView(gw);
		
		gw.addObserver(mv); // register map observer
		gw.addObserver(sv); // register score view observer

		
		this.setLayout(new BorderLayout());
		Command exitCommand = new CommandExit(gw);
		Command accelerateCommand = new CommandAccelerate(gw);
		Command leftCommand = new CommandLeftHeading(gw);
		Command breakCommand = new CommandBreak(gw);
		Command rightCommand = new CommandRightHeading(gw);
		Command spidercollideCommand = new CommandSpiderCollision(gw);
		Command foodCommand = new CommandFoodStationCollision(gw);
		Command tickCommand = new CommandGameTimeTick(gw);
		
		addKeyListener('x', exitCommand);
		addKeyListener('a', accelerateCommand);
		addKeyListener('b', breakCommand);
		addKeyListener('l', leftCommand);
		addKeyListener('r', rightCommand);
		addKeyListener('f', foodCommand);
		addKeyListener('g', spidercollideCommand);
		addKeyListener('t', tickCommand);
		
		//West Container
				Container westContainer = new Container();
				westContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.GRAY));
				westContainer.setLayout(new BoxLayout(2));
				
		//Accelerate
		Button accelerateButton = new Button("Accelerate");
		accelerateButton.setCommand(accelerateCommand);
		westContainer.addComponent(accelerateButton);
		accelerateButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		accelerateButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		accelerateButton.getAllStyles().setBgTransparency(255);
		accelerateButton.getAllStyles().setMarginBottom(10); 
		
		
		//Left
		Button leftButton = new Button("Left");
		leftButton.setCommand(leftCommand);
		westContainer.addComponent(leftButton);	
		leftButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		leftButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		leftButton.getAllStyles().setBgTransparency(255);	
		leftButton.getAllStyles().setMarginBottom(10);
		
		
		//East Container 
		Container eastContainer = new Container();
		eastContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.GRAY));
		eastContainer.setLayout(new BoxLayout(2));
		
		//Break
		Button breakButton = new Button("Break");
		breakButton.setCommand(breakCommand);
		eastContainer.addComponent(breakButton);
		breakButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		breakButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		breakButton.getAllStyles().setBgTransparency(255);	
		breakButton.getAllStyles().setMarginBottom(10);
				
		//Right
		Button rightButton = new Button("Right");
		rightButton.setCommand(rightCommand);
		eastContainer.addComponent(rightButton);
		rightButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		rightButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		rightButton.getAllStyles().setBgTransparency(255);	
		rightButton.getAllStyles().setMarginBottom(10);
				
		Container centerContainer = new Container();
		centerContainer.getAllStyles().setBorder(Border.createLineBorder(4,ColorUtil.MAGENTA));

		//South Container
		Container southContainer = new Container();
		southContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.GRAY));
		southContainer.setLayout(new FlowLayout(Component.CENTER));	
		
		//Collide with base
		Button flagButton = new Button("Collide with Flag");
		flagButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		flagButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		flagButton.getAllStyles().setBgTransparency(255);	
		flagButton.getAllStyles().setMarginRight(5);
		southContainer.addComponent(flagButton);
				
		//Collide with Spider
		Button collideButton = new Button("Collide with Spider");
		southContainer.addComponent(collideButton);
		collideButton.setCommand(spidercollideCommand);
		collideButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		collideButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		collideButton.getAllStyles().setBgTransparency(255);	
		collideButton.getAllStyles().setMarginRight(5);
				
		//Collide with Food Station
		Button foodButton = new Button("Collide with Food Station");
		southContainer.add(foodButton);
		foodButton.setCommand(foodCommand);
		foodButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		foodButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		foodButton.getAllStyles().setBgTransparency(255);	
		foodButton.getAllStyles().setMarginRight(5);
				
		//Tick/game time
		Button tickButton  = new Button("Tick");
		tickButton.setCommand(tickCommand);
		southContainer.add(tickButton);
		tickButton.getAllStyles().setFgColor(ColorUtil.WHITE);
		tickButton.getAllStyles().setBgColor(ColorUtil.BLUE);
		tickButton.getAllStyles().setBgTransparency(255);	
		tickButton.getAllStyles().setMarginRight(5);
		
		
		//setup the toolbar for the gui
		Toolbar toolbar = new Toolbar();
		this.setToolbar(toolbar);
		toolbar.setTitle("BugZ Game ");
				
		//toolbar 
		toolbar.addCommandToSideMenu(accelerateCommand);
		Command soundCommand = new CommandSound(gw);
		CheckBox soundCheck = new CheckBox("Sound");
		soundCheck.setCommand(soundCommand);
		toolbar.addComponentToSideMenu(soundCheck );
		Command aboutInfoCommand = new CommandAbout(gw);
		toolbar.addCommandToSideMenu(aboutInfoCommand);

		toolbar.addCommandToSideMenu(exitCommand);	
				
		Command helpButton = new CommandHelp(gw);
		toolbar.addCommandToRightBar(helpButton);
				
		this.add(BorderLayout.WEST, westContainer);
		this.add(BorderLayout.EAST, eastContainer);
		this.add(BorderLayout.SOUTH, southContainer);
		this.add(BorderLayout.NORTH, mv);
		this.add(BorderLayout.CENTER, sv);
		gw.setMapHeight(mv.getComponentForm().getHeight());
		gw.setMapWidth(mv.getComponentForm().getWidth());
		gw.init();
		this.show();
}
	
	

	@SuppressWarnings({ "unused", "rawtypes" })
	private void play() {
		//accept and execute user commands that operate on the game world
		Label myLabel=new Label("Enter a Command:");
		this.addComponent(myLabel);
		final TextField myTextField=new TextField();
		this.addComponent(myTextField);
		this.show();
		
		myTextField.addActionListener(new ActionListener(){
		
			public void actionPerformed(ActionEvent evt) {
		
				String sCommand=myTextField.getText().toString();
				myTextField.clear();
		        switch (sCommand.charAt(0)) {
		        	
		        case 'a':
		        	// accelerate
		        	gw.setAntSpeed(5);
		        	break;
		        	
		        case 'b':
		            //break
		        	System.out.println("Break is applied");
		        	gw.setAntSpeed(-5);
		        	break;
		        
		        case 'l':
		        	//change heading to left
		        	gw.changeHeading('l');
		        	break;
		        	
		        case 'r':
		        	//change heading to right
		        	gw.changeHeading('r');
		        	break;
		        	
		        case '1':
		        	//flag 1
		        	gw.flagCollision(1);
		        	break;
		        
		        case '2':
		        	//flag 2
		        	gw.flagCollision(2);
		        	break;
		        	
		        case '3':
		        	//flag 3
		        	gw.flagCollision(3);
		        	break;
		        	
		        case '4':
		        	//flag 4
		        	gw.flagCollision(4);
		        	break;
		        	
		        case '5':
		        	//flag 5
		        	gw.flagCollision(5);
		        	break;
		        	
		        case '6':
		        	//flag 6
		        	gw.flagCollision(6);
		        	break;
		        	
		        case '7':
		        	//flag 7
		        	gw.flagCollision(7);
		        	break;
		        	
		        case '8':
		        	//flag 8
		        	gw.flagCollision(8);
		        	break;
		        	
		        case '9':
		        	//flag 9
		        	gw.flagCollision(9);
		        	break;
		        	
		        case 'f':
		        	//food station collision
		        	gw.foodStationCollision();
		        	break;
		        	
		        case 'g':
		        	//spider collision
		        	gw.antCollision('d');
		        	break;
		        	
		        case 't':
		        	gw.tick();
		        	break;
		        	
		        case 'd':
		        	gw.display();
		        	break;
		        	
		        case 'm':
		        	gw.map();
		        	break;
		        	
		        case 'x':
			        	// Exit game
		        	    myLabel.setText("Do you want to exit? Press y or n!");
			        	gw.quitGame();
			        	break;	
			        	
		        case 'y':
		        	gw.exit();
		        	break;
		        	
		        case 'n':
		        	gw.dontQuit();
		        	myLabel.setText("Enter a command!");
		        	break;
		        	
		        	
		        	
		//add code to handle rest of the commands
		} //switch
		} //actionPerformed
		}); //new ActionListener()
		 //addActionListener
		} //play
}	
	

				



