//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CommandGameTimeTick extends Command {
    private GameWorld gw;

    //tick clock time
    public CommandGameTimeTick(GameWorld gw){
        super("Tick");
        this.gw = gw;
    }

    
    @Override
    public void actionPerformed(ActionEvent ev){
        gw.tick();
    }
}
