//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import java.util.Random;
import com.codename1.charts.util.ColorUtil;
import java.util.Observable;

public class GameWorld extends Observable {
	//create the initial game objects/setup 
	
	//Ant 
	private PlayerAnt ant;
	private int clock = 0;
	private boolean soundCheck = false;
	private int flagSize = 10;
	private int antSize = 30;
	
	//Timer
	private boolean isExit = true;
	@SuppressWarnings("unused")
	private int winningFlag = 4;
	GameObjectCollection gameObjectList;
	
	
	
	@SuppressWarnings("unused")
	private boolean soundOn = false;
	private int mapHeight;
	private int mapWidth;
	@SuppressWarnings("unused")
	private int lives;
	private int counter = 0;
	private Random rand = new Random();
	
	public GameWorld() {
		gameObjectList = new GameObjectCollection();
		ant = new PlayerAnt(antSize, 0, 500, 500);
	}
	
	//quit game options
	public void exit() {
		if (isExit)
			System.exit(0);
	}
	public void quitGame() {
		System.out.println("Do you want to exit? Press y or n!");
		isExit=true;
	}
	public void dontQuit() {
		isExit=false; 
	}
	
	
	public void setMapHeight(int height) {
		this.mapHeight = height;
		System.out.println("" + height);
	}
	
	public void setMapWidth(int width) {
		this.mapWidth = width;
	}
	
	
	// Start of the game
	public void init()
    {
		
		//create objects
		gameObjectList.add(new Flags(flagSize, 1, 200, 300)); //flag 1
		gameObjectList.add(new Flags(flagSize, 2, 100, 200)); //flag 2
		gameObjectList.add(new Flags(flagSize, 3, 400, 500)); //flag 3
		gameObjectList.add(new Flags(flagSize, 4, 600, 900)); //flag 4
		
		gameObjectList.add(new FoodStations(randObjSize(), randX(), randY())); //food1
		gameObjectList.add(new FoodStations(randObjSize(), randX(), randY())); //food2
		
		//create Ant player
		gameObjectList.add(ant);
		
		//create Spider object
		gameObjectList.add(new Spider(randObjSize(), randX(), randY())); //spider 1
		gameObjectList.add(new Spider(randObjSize(), randX(), randY())); //spider 2
		
		this.setChanged();
		this.notifyObservers();
    }
	
	//display game
	public void display() {
		System.out.println("Time: "+counter+", Lives Left: " + ant.getLives()
		+       ",  Food Level: " +ant.getFoodLevel()+", Health Level: "+ant.getHealthLevel());
	}
	
	//display game map
	public void map() {
		System.out.println();
		IIterator elements = gameObjectList.getIterator();
		while (elements.hasNext()) {
			GameObject temp = ((GameObject) elements.getNext());
			System.out.println(temp.toString());
		}
	}
	
	private void lifeReset() {
		ant.resetAnt();
	}
	
	public void toggleSound() {
		this.soundCheck = !(this.soundCheck);
		this.setChanged();
		this.notifyObservers();
	}
	
	// tick command
	public void tick() {
		if(ant.getHealthLevel()!=100 && ant.getFoodLevel() !=0 && ant.getLives()!=0){
			ant.setHeading(ant.getHeading());
			ant.setFoodLevel(300);
			counterTime();
		
		IIterator elements = gameObjectList.getIterator();
		while (elements.hasNext()) {
			GameObject temp = ((GameObject) elements.getNext());
				if(temp instanceof Moveable) {
					if(temp instanceof Spider) {
					((Moveable) temp).setHeading(((Moveable) temp).getHeading());
					((Moveable) temp).move();
				}
				
				else
					((Moveable) temp).move();
			}
		}
	}
		else {
			if (ant.getLives()!= 0) {
				lifeReset();
			}
			else
			{
				System.out.println("Game over, you failed!");
			}
		}
		
		notifyobs();
		
	}
	
	public int getFoodLevel() {
		return ant.getFoodLevel();
	}
	
	public int getHealthLevel() {
		return ant.getHealthLevel();
	}
	
	public String isSound() {
		if (this.soundCheck) {
			return " ON";
		}
		else {
			return " OFF";
		}
	}
	
	
	public void antCollision(char with) {
		ant.collision(with);
		IIterator iterator = gameObjectList.getIterator();
		while(iterator.hasNext()) {
			GameObject temp = (GameObject) iterator.getNext();
			if(temp instanceof PlayerAnt) {
				((PlayerAnt) temp).collision('r');
				break;
			}
		}
		notifyobs();
	}
	
	//Create randInts
	private int randX() {
		return rand.nextInt(mapWidth);
	}
	
	private int randY() {
		return rand.nextInt(mapHeight);
	}
	
	private int randObjSize() {
		return 30+rand.nextInt(50);
	}
	
	public void flagCollision (int flagNumber) {
		ant.FlagCollision(flagNumber);
		notifyobs();
	}
	
	public void setAntSpeed(int x) {
		ant.setSpeed(ant.getSpeed()+x);
		notifyobs();
	}
	
	public void changeHeading (char change) {
		ant.changeHeading(change);
		notifyobs();
	}
	
	public int getLives()
	{
		return ant.getLives();
	}
	
	public int getTime() {
		return counter;
	}
	
	public void foodStationCollision() {
		IIterator iterator = gameObjectList.getIterator();
		while(iterator.hasNext()) {
			GameObject temp = (GameObject) iterator.getNext();
			if (temp instanceof FoodStations) {
				if(((FoodStations) temp).getCapacity()!=0) {
					ant.setFoodLevel(((FoodStations) temp).getCapacity());
					((FoodStations)temp).setCapacity();
					temp.setColor(ColorUtil.rgb(0, 255, 0));
					break;
				}
			}
		}
		gameObjectList.add(new FoodStations(randObjSize(), randX(), randY()));
	}
	
	public void counterTime() {
		counter += 1;
	}
	
	public void gameOverLoss() {
		System.out.println("Game over, you lost!");
		ant = null;
		this.exit();
	}
	
	public void gameOverWin() {
		System.out.println("Game over, you win! Total time: " + this.clock);
	}
	
	private void notifyobs() {
		this.setChanged();
		this.notifyObservers();
	}

}

