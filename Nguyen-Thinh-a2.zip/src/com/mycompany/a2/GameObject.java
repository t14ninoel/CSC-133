//Name: Thinh Dac Nguyen
//Student ID: 219903243
//CSC 133 FALL 2019 

package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;

public abstract class GameObject {
	private int myColor; //color attribute
	private double x = 0; //location attribute
	private double y = 0; //location attribute
	@SuppressWarnings("unused")
	private int size; //size attribute
	
	public GameObject(int size, double x, double y) {
		this.size = size;
		this.x = x;
		this.y = y;     
	}

	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setX(double x) {
		this.x = x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public void setColor(int color) {
		myColor = color;
	}
	
	public int getColor() {
		return myColor;
	}
	
	public String toString() {
		
		String myDesc = "  location=" + Math.round(x*10.0)/10.0 + "," + Math.round(y*10.0)/10.0 +
				" color=[" + ColorUtil.red(myColor)+ "," +ColorUtil.green(myColor) + "," +ColorUtil.blue(myColor) + "]";
		return myDesc;
	}
}
